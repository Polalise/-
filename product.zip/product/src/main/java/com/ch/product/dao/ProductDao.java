package com.ch.product.dao;

import java.util.List;

import com.ch.product.model.Product;

public interface ProductDao {
	int getMaxNum = 0;
	int getTotal(Product prodcut);
	int getMaxNum();
	int insert(Product product);
	Product select(int p_num);
	void updateReadCount(int p_num);
	int update(Product product);
	int delete(Product product);
	List<Product> list(Product product);

	

}
 