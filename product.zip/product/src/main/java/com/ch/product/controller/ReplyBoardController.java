package com.ch.product.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ch.product.model.Product;
import com.ch.product.model.ReplyBoard;
import com.ch.product.service.ProductService;
import com.ch.product.service.ReplyBoardService;
@Controller
public class ReplyBoardController {
	@Autowired
	private ReplyBoardService rbs;
	@Autowired
	private ProductService ps;
	@RequestMapping("replyList")
	public String replyList( int bno, Model model) {
		Product product = ps.select(bno);
		List<ReplyBoard> rbdList = rbs.list(bno);
		model.addAttribute("product", product);
		model.addAttribute("rbdList", rbdList);
		return "replyList";
	}
	@RequestMapping("rInsert")
	public String rInsert(ReplyBoard rb) {
		rbs.insert(rb);
		return "redirect:replyList.po?bno="+rb.getBno();			
	}
	@RequestMapping("rUpdate")
	public String rUpdate(ReplyBoard rb) {
		rbs.update(rb);
		return "redirect:replyList.po?bno="+rb.getBno();
	}
	@RequestMapping("rDelete")
	public String rDelete(ReplyBoard rb) {
		System.out.println("rb3:" + rb);
		rbs.delete(rb);
		return "redirect:replyList.po?bno="+rb.getBno();
	}
} 