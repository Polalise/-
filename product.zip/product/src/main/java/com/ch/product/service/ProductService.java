package com.ch.product.service;
import java.util.List;

import com.ch.product.model.Product;


public interface ProductService {
	int getTotal(Product product);
	int getMaxNum();
	int insert(Product product);
	Product select(int p_num);
	void updateReadCount(int p_num);
	int update(Product product);
	int delete(Product product);
	List<Product> list(Product product);

}
