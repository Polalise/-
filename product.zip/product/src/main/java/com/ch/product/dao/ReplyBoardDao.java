package com.ch.product.dao;
import java.util.List;
import com.ch.product.model.ReplyBoard;
public interface ReplyBoardDao {
	List<ReplyBoard> list(int bno);
	void insert(ReplyBoard rb);
	void update(ReplyBoard rb);
	void delete(ReplyBoard rb);
}