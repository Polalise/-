drop table product;
select
CREATE TABLE product(
	p_num NUMBER primary key,
	p_writer varchar2(100) NOT NULL, -- 작성자
	p_name varchar2(100), --제목
	price NUMBER NOT NULL, -- 판매가격
	p_date DATE, -- 등록 날짜
	p_content varchar2(4000) NOT NULL, -- 본문
	p_local VARCHAR2(20) , -- 지역
	p_value varchar2(10) , --판매 구매 나누기	
	readcount number default 0, -- 읽은 횟수
	p_del char(1) default 'n', -- 삭제 여부 
	updateday DATE,-- 게시글수정일
	sel	char(1), --거례여부
	likescount NUMBER, -- 좋아요갯수
	p_tag	varchar2(100), --해쉬 테그
	buyer varchar2(100), -- 구매자	
	ip varchar2(20), -- 작성자 ip
	thumnails varchar2(100) NOT NULL, -- 계시글 사진
	thumnails2 varchar2(100) default null,
	thumnails3 varchar2(100) default null,
	thumnails4 varchar2(100) default null,
	thumnails5 varchar2(100) default null,
	id VARCHAR2(100) REFERENCES members ON DELETE CASCADE
);

drop table replyBoard;
create table replyBoard (
	rno number primary key,
	bno number not null references product(p_num),
	replytext varchar2(500) not null,
	replier varchar2(50) not null,
	regdate date not null,
	updatedate date not null,
	del char(1) 
);
select * from board2 order by num desc;
insert into replyboard values(1,5,'비오나','박쌍칼',sysdate,sysdate,'n');
insert into replyboard values(2,5,'금요일','영희',sysdate,,sysdate,'n');
insert into replyboard values(3,5,'비오나','나다',sysdate,sysdate,'n');

select * from product;

select 
